export const iex = {
    api_token: "pk_071b7ebfb3784739a62c882b93cfbfed",
    base_url: "https://cloud.iexapis.com/stable"
};