export const alphavantage = {
  api_token: "ICG1T5IU2X7MPB62",
  base_url: "https://www.alphavantage.co/query?",
};
